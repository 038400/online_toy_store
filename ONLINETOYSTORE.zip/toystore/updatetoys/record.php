<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "toystore";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">Toys RECORD Update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>product id</th>
<th>Toys</th>
<th>Company</th>
<th>Amount</th>


</tr>
<?php
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Product_id'];?></td>
<td> <?php  echo $row['Toys'];?></td>
<td> <?php  echo $row['Perfume'];?></td>
<td> <?php  echo $row['Amount'];?></td>


 <td><a href="edit.php?edit_id=<?php echo $row['Product_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>