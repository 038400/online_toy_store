drop database toystore;
show databases;
create database toystore;
use toystore;
CREATE TABLE User (
    User_ID int,
    User_gender varchar(30),
    Gold_user varchar(30),
    Platinum_user varchar(30),
    admin varchar(30)
);
CREATE TABLE Category (
    Product_brand varchar(30),
    For_male varchar(30),
    For_female varchar(30)
);
CREATE TABLE Products (
    Product_id int ,
    Toys varchar(30),
    Perfume varchar(30),
    Amount int
);
CREATE TABLE Payments (
    Product_id int ,
    User_ID int,
    Method varchar(30),
    Amount int
);
CREATE TABLE Orderr (
    Ordered_things varchar(30) ,
    User_ID int,
    User_gender varchar(30)
);
CREATE TABLE Buys (
    User_ID int,
    Product_id int
);
CREATE TABLE Purchase_Through (
    User_ID int
);
CREATE TABLE Organized_by (
    Product_id int
);
CREATE TABLE byy (
    User_ID int,
    Product_id int,
    Ordered_things varchar(30)
);
desc user;
alter table user add primary key (user_id);
alter table products add primary key (product_id);
alter table payments add primary key (product_id);
alter table orderr add primary key (user_id);
alter table orderr drop primary key;
alter table buys add primary key (user_id);
alter table buys drop primary key;
alter table Purchase_Through add primary key (user_id);
alter table Organized_by add primary key (product_id);
alter table byy add primary key (Ordered_things);
alter table user add column (fisrtname varchar (30),lastname varchar(30),contact int,email varchar (30),adress varchar(30));
alter table payments add foreign key (user_id) references user(user_id);
alter table orderr add  foreign key (user_id) references user(user_id);
alter table buys add foreign key  (user_id) references user(user_id);
alter table Purchase_Through add foreign key  (user_id) references user(user_id);
alter table byy add foreign key  (user_id) references user(user_id);
alter table payments add foreign key (product_id) references products(product_id);
alter table buys add foreign key (product_id) references products(product_id);
alter table Organized_by add foreign key (product_id) references products(product_id);
alter table byy add foreign key (product_id) references products(product_id);
alter table orderr add foreign key(Ordered_things) references byy(Ordered_things);
insert into products ( product_id,toys,perfume,amount)
values ('1','Chess Board','Musk','500');
insert into products ( product_id,toys,perfume,amount)
values ('2','RC Car','AXE','1000');
insert into products ( product_id,toys,perfume,amount)
values ('3','Bike','Blue Water','2000');
insert into products ( product_id,toys,perfume,amount)
values ('4','Helicopter','Vikings','3000');
insert into user ( User_id,User_gender,Gold_user,Platinum_user)
values ('1','Male','Yes','No');
insert into user ( User_id,User_gender,Gold_user,Platinum_user)
values ('2','Female','Yes','No');
insert into user ( User_id,User_gender,Gold_user,Platinum_user)
values ('3','Female','No','Yes');
insert into user ( User_id,User_gender,Gold_user,Platinum_user)
values ('4','Male','No','Yes');
insert into Category (Product_brand,for_male,for_female)
values ('Uniliver','YES','NO');
insert into Category (Product_brand,for_male,for_female)
values ('Ponds','NO','YES');
insert into Category (Product_brand,for_male,for_female)
values ('Gillete','YES','NO');
insert into Category (Product_brand,for_male,for_female)
values ('Dove','NO','YES');
insert into payments ( product_id,User_id,method,amount)
values ('4','1','COD','3000');
insert into payments ( product_id,User_id,method,amount)
values ('3','2','Debt Card','2000');
insert into payments ( product_id,User_id,method,amount)
values ('1','3','Debt Card','1000');
insert into payments ( product_id,User_id,method,amount)
values ('2','4','COD','500');
insert into buys ( User_id,Product_id)
values ('1','4');
insert into buys ( User_id,Product_id)
values ('2','3');
insert into buys ( User_id,Product_id)
values ('3','1');
insert into buys ( User_id,Product_id)
values ('4','2');
insert into Purchase_through ( User_id)
values ('1');
insert into Purchase_through ( User_id)
values ('2');
insert into Purchase_through ( User_id)
values ('3');
insert into Purchase_through ( User_id)
values ('4');
insert into Organized_by ( Product_id)
values ('1');
insert into Organized_by ( Product_id)
values ('2');
insert into Organized_by ( Product_id)
values ('3');
insert into Organized_by ( Product_id)
values ('4');
insert into byy ( User_id,Product_id,Ordered_things)
values ('1','4','Chess Board');
insert into byy ( User_id,Product_id,Ordered_things)
values ('2','3','RC Car');
insert into byy ( User_id,Product_id,Ordered_things)
values ('3','1','Bike');
insert into byy ( User_id,Product_id,Ordered_things)
values ('4','2','Helicopter');